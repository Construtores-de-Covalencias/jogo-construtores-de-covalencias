import pygame
pygame.init()

# Questão 1
opcoes_questao1 = [
    "Troca de elétrons",
    "Compartilhamento de elétrons",
    "Transferência de prótons"
]

# Questão 2
opcoes_questao2 = [
    "Um ânion negativo",
    "Um cátion positivo",
    "Um neutrônio"
]

# Questão 3
opcoes_questao3 = [
    "Compartilhamento de elétrons",
    "Doação de elétrons",
    "Livre movimento de elétrons"
]

# Questão 4
opcoes_questao4 = [
    "1",
    "2",
    "3"
]

# Questão 5
opcoes_questao5 = [
    "NaCl",
    "Na2Cl",
    "NaCl2"
]

# Questão 6
opcoes_questao6 = [
    "Ferro",
    "Alumínio",
    "Mercúrio"
]

# Questão 7
opcoes_questao7 = [
    "Covalente polar",
    "Covalente não polar",
    "Ligação metálica"
]

# Questão 8
opcoes_questao8 = [
    "Ouro puro",
    "Latão (liga de cobre e zinco)",
    "Vidro metálico"
]

# Questão 9
opcoes_questao9 = [
    "Compartilhamento de elétrons",
    "Atratividade iônica",
    "Elétrons livres"
]

# Questão 10
opcoes_questao10 = [
    "O",
    "O2",
    "2O"
]

# Questão 11
opcoes_questao11 = [
    "Um átomo com carga positiva",
    "Um átomo com carga negativa",
    "Um átomo sem carga"
]

# Questão 12
opcoes_questao12 = [
    "Devido ao movimento rápido dos elétrons",
    "Devido à ausência de elétrons",
    "Devido à presença de prótons"
]

# Questão 13
opcoes_questao13 = [
    "Linear",
    "Angular",
    "Tetraédrica"
]

# Questão 14
opcoes_questao14 = [
    "Metais",
    "Não-metais",
    "Gases nobres"
]

# Questão 15
opcoes_questao15 = [
    "Sólidas à temperatura ambiente",
    "Líquidas à temperatura ambiente",
    "Gasosas à temperatura ambiente"
]

# Questão 16
opcoes_questao16 = [
    "Covalente polar",
    "Covalente não polar",
    "Ligação metálica"
]

# Questão 17
opcoes_questao17 = [
    "Um átomo positivo",
    "Um átomo negativo",
    "Um átomo neutro"
]

# Questão 18
opcoes_questao18 = [
    "Um elétron dentro do núcleo de um átomo",
    "Um elétron compartilhado entre dois átomos",
    "Um elétron que não pertence a nenhum átomo específico"
]

# Questão 19
opcoes_questao19 = [
    "NaCl",
    "O2",
    "NaOH"
]

# Questão 20
opcoes_questao20 = [
    "Negativa",
    "Positiva",
    "Neutra"
]

# Questão 21
opcoes_questao21 = [
    "Neutron",
    "Ânion",
    "Cátion"
]

# Questão 22
opcoes_questao22 = [
    "Covalente polar",
    "Iônica apolar",
    "Metálica"
]

# Questão 23
opcoes_questao23 = [
    "Covalente",
    "Iônica",
    "Metálica"
]

# Questão 24
opcoes_questao24 = [
    "Um elétron que está em movimento constante dentro do núcleo de um átomo.",
    "Um elétron na camada mais interna de um átomo",
    "um elétron na camada mais externa de um átomo"
]

# Questão 25
opcoes_questao25 = [
    "Sua capacidade de serem moldados em fios",
    "Sua capacidade de serem quebrados facilmente",
    "Sua capacidade de serem voláteis"
]



lista_opcoes = [
    opcoes_questao1, opcoes_questao2, opcoes_questao3, opcoes_questao4,
    opcoes_questao5, opcoes_questao6, opcoes_questao7, opcoes_questao8,
    opcoes_questao9, opcoes_questao10, opcoes_questao11, opcoes_questao12,
    opcoes_questao13, opcoes_questao14, opcoes_questao15, opcoes_questao16,
    opcoes_questao17, opcoes_questao18, opcoes_questao19, opcoes_questao20,
    opcoes_questao21, opcoes_questao22, opcoes_questao23, opcoes_questao24,
    opcoes_questao25
]




# Ligação Covalente
respostas_corretas = [
    "Compartilhamento de elétrons",
    "Um ânion negativo",
    "Livre movimento de elétrons",
    "2",
    "NaCl",
    "Mercúrio",
    "Covalente polar",
    "Latão (liga de cobre e zinco)",
    "Elétrons livres",
    "O2",
    "Um átomo com carga positiva",
    "Devido ao movimento rápido dos elétrons",
    "Angular",
    "Metais",
    "Sólidas à temperatura ambiente",
    "Covalente não polar",
    "Um átomo negativo",
    "Um elétron que não pertence a nenhum átomo específico",
    "O2",
    "Negativa",
    "Cátion",
    "Covalente polar",
    "Iônica",
    "um elétron na camada mais externa de um átomo",
    "Sua capacidade de serem moldados em fios"
]





lista_perguntas = [
    "O que acontece na ligação covalente?",
    "Quando um átomo ganha elétrons durante a ligação iônica, ele se torna:",
    "O que é característico das ligações metálicas?",
    "Quantos elétrons são compartilhados em uma ligação covalente simples?",
    "Qual é o nome do composto formado pela ligação iônica entre sódio (Na) e cloro (Cl)?",
    "Qual é o exemplo de um metal que é líquido à temperatura ambiente?",
    "Em que tipo de ligação os átomos compartilham elétrons de forma desigual?",
    "Qual é o exemplo de uma liga metálica?",
    "A condutividade elétrica em metais é alta devido a:",
    "Qual é a fórmula química para o gás oxigênio diatômico?",
    "O que é um cátion?",
    "Por que os metais são bons condutores de calor?",
    "Qual é a geometria molecular da molécula de água (H2O)?",
    "A que grupo na tabela periódica os átomos que tendem a formar cátions pertencem?",
    "Qual é a característica física das substâncias metálicas?",
    "Em que tipo de ligação os átomos compartilham elétrons de forma igual?",
    "O que é um ânion?",
    "O que é um elétron livre em uma ligação metálica?",
    "Qual é o exemplo de uma molécula diatômica que é mantida por uma ligação covalente?",
    "Qual é a carga de um ânion?",
    "Qual é o nome do íon com carga positiva?",
    "O dióxido de carbono (CO2) possui que tipo de ligação entre carbono e oxigênio?",
    "Os sais são geralmente compostos por que tipo de ligação?",
    "O que é um elétron de valência?",
    "Qual é a característica de maleabilidade dos metais?"
]


tamanho_da_tela = pygame.display.Info()
largura = tamanho_da_tela.current_w
altura = tamanho_da_tela.current_h
escala_x = largura/1536
escala_y = altura/864
fonte2 = pygame.font.Font(None, int(70 * escala_y))


def quebra_linhas(texto, largura_maxima):
    palavras = texto.split()
    linhas = []
    linha_atual = ""

    for palavra in palavras:
        if linha_atual:
            teste_linha = linha_atual + " " + palavra
        else:
            teste_linha = palavra
        larg, alt = fonte2.size(teste_linha)

        if larg <= largura_maxima:
            linha_atual = teste_linha
        else:
            linhas.append(linha_atual)
            linha_atual = palavra
    if linha_atual:
        linhas.append(linha_atual)

    return linhas

dicas = [
    "Uma negociação entre os dois átomos",
    "Como você fica quando deve dinheiro?",
    "Do mesmo jeito que as pessoas se sentem quando fazem 18 anos",
    "92/x = 46",
    "Nome técnico para sal de cozinha",
    "Super herói rápido",
    "Lembra pessoas que mudam rápido de personalidade",
    "Lembra um dos personagens de O Mágico de Oz",
    "O mesmo que quando o ladrão sai da cadeia",
    "Oxigênio multiplicado por 2",
    "Lembra uma marca de computadores brasileira",
    "Como o poder do Sonic",
    "Palavra muito usada na Matemática",
    "Material resistente",
    "Que nem uma rocha",
    "É diferente de um imã",
    "um átomo triste",
    "Um eletron sem pais",
    "Diatomica significa dois átomos",
    "O ânion é formado ao ganhar elétron",
    "So possui duas letras de diferença com o de carga negativa",
    "Como os pontos mais frios do planeta terra",
    "Os sais são formados por ânios e cátions",
    "ele vive no lugar mais longe dos prótons",
    "Muito ligado à energia"

]

q_1 = ["hidrogenio", "oxigenio", "hidrogenio", None]
q_2 = ["oxigenio", "carbono", "oxigenio", None]
q_3 = ["oxigenio", "oxigenio", None, None]
q_4 = ["oxigenio", "enxofre", "oxigenio", None]
q_5 = ["hidrogenio", "nitrogenio", "hidrogenio", "hidrogenio"]
q_6 = ["hidrogenio", "hidrogenio", None, None]
q_7 = ["hidrogenio", "enxofre", "hidrogenio", None]
q_8 = ["oxigenio", "oxigenio", "oxigenio", None]
q_9 = ["cloro", "cloro", None, None]
q_10 = ["enxofre", "carbono", "enxofre", None]
q_11 = ["fluor", "fluor", "boro", "fluor"]
q_12 = ["nitrogenio", "nitrogenio", None, None]
q_13 = ["hidrogenio", "carbono", "nitrogenio", None]
q_14 = ["hidrogenio", "fosforo", "hidrogenio", "hidrogenio"]
q_15 = ["hidrogenio", "selenio", "hidrogenio", None]
lista_resposta_ligacoes = [
    q_1,
    q_2,
    q_3,
    q_4,
    q_5,
    q_6,
    q_7,
    q_8,
    q_9,
    q_10,
    q_11,
    q_12,
    q_13,
    q_14,
    q_15,
]

titulos_teoria = [
    "Ligação Covalente : ligação covalente simples",
    "Ligação Covalente : ligação covalente dupla",
    "Ligação Covalente : ligação covalente tripla",
    "Ligação Covalente : Entre que átomos ocorre",
    "Ligação Iônica: Como é?",
    "Ligação Iônica: Entre que átomos ocorre",
    "Ligação Metálica: Como é?",
    "Ligação Metálica: Entre que átomos ocorre",
    "ligação Metálica: Caracteristicas"
]
textos_teoria = [
    "Na ligação covalente cada átomo compartilha um elétron com o outro átomo assim formando um par de elétrons. Quando os átomos compartilham apenas um par isso se chama ligação simples",
    "Quando os átomos compartilham dois pares isso se chama ligação dupla",
    "Quando os átomos compartilham três pares isso se chama ligação tripla",
    "ligações covalentes ocorrem entre:  Ametal + Ametal, Ametal + Hidrogênio e Hidrogênio + Hidrogênio",
    "Na ligação iônica um átomo cede elétrons para o outro, assim se formando um cátion positivo (o átomo que cedeu elétrons) e um ânion negativo (o atomo que recebeu)",
    "Ligações iônicas ocorrem entre: Metal + Ametal, Metal + hidrogênio",
    "Na ligação metálica os elétrons dos átomos ficam livres devido a alta capacidade que os metais possuem de ceder elétrons.",
    "ligações metálicas ocorrem entre: Metal + Metal",
    "Os compostos metálicos possuem algumas caracteristicas como: Ductibilidade, maleabilidade, condutividade termica e eletrica e possuem altos pontos de ebulição e fusão"
]

