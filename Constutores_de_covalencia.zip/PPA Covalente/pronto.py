import pygame
from e import *
import math

pygame.init()
pygame.mixer.init()

som_acerto = pygame.mixer.Sound("sons/short-success-sound-glockenspiel-treasure-video-game-6346.mp3")
som_erro = pygame.mixer.Sound("sons/error-126627.mp3")
som_acerto.set_volume(1.0)
som_erro.set_volume(1.0)


class Atomo:
    def __init__(self, x, y, cor, raio, elemento):
        self.cor = cor
        self.x = x
        self.y = y
        self.raio = raio
        self.movendo = False
        self.elemento = elemento
        self.prev_x = self.x
        self.prev_y = self.y
        self.sobreposto = False

    def draw(self):
        self.retangulo = pygame.draw.circle(tela, self.cor, (self.x, self.y), self.raio)

    def update(self):
        if self.movendo:
            self.x, self.y = posicao_mouse
            self.sobreposto = False

            if telas[2]:
                for atom in lista_atomos_atomos[questao_2]:
                    if atom != self:
                        distancia = math.sqrt((self.x - atom.x) ** 2 + (self.y - atom.y) ** 2)
                        if distancia < (self.raio + atom.raio):
                            # Se os átomos estão muito próximos, mova-os para longe um do outro
                            angulo = math.atan2(self.y - atom.y, self.x - atom.x)
                            nova_x = atom.x + (self.raio + atom.raio) * math.cos(angulo)
                            nova_y = atom.y + (self.raio + atom.raio) * math.sin(angulo)
                            self.x, self.y = nova_x, nova_y
            elif telas[5]:
                for atom in lista_atomos_atomos[questao_2 + 3]:
                    if atom != self:
                        distancia = math.sqrt((self.x - atom.x) ** 2 + (self.y - atom.y) ** 2)
                        if distancia < (self.raio + atom.raio):
                            # Se os átomos estão muito próximos, mova-os para longe um do outro
                            angulo = math.atan2(self.y - atom.y, self.x - atom.x)
                            nova_x = atom.x + (self.raio + atom.raio) * math.cos(angulo)
                            nova_y = atom.y + (self.raio + atom.raio) * math.sin(angulo)
                            self.x, self.y = nova_x, nova_y
            elif telas[7]:
                for atom in lista_atomos_atomos[questao_2 + 6]:
                    if atom != self:
                        distancia = math.sqrt((self.x - atom.x) ** 2 + (self.y - atom.y) ** 2)
                        if distancia < (self.raio + atom.raio):
                            # Se os átomos estão muito próximos, mova-os para longe um do outro
                            angulo = math.atan2(self.y - atom.y, self.x - atom.x)
                            nova_x = atom.x + (self.raio + atom.raio) * math.cos(angulo)
                            nova_y = atom.y + (self.raio + atom.raio) * math.sin(angulo)
                            self.x, self.y = nova_x, nova_y
            elif telas[8]:
                for atom in lista_atomos_atomos[questao_2 + 9]:
                    if atom != self:
                        distancia = math.sqrt((self.x - atom.x) ** 2 + (self.y - atom.y) ** 2)
                        if distancia < (self.raio + atom.raio):
                            # Se os átomos estão muito próximos, mova-os para longe um do outro
                            angulo = math.atan2(self.y - atom.y, self.x - atom.x)
                            nova_x = atom.x + (self.raio + atom.raio) * math.cos(angulo)
                            nova_y = atom.y + (self.raio + atom.raio) * math.sin(angulo)
                            self.x, self.y = nova_x, nova_y
            elif telas[9]:
                for atom in lista_atomos_atomos[questao_2 + 12]:
                    if atom != self:
                        distancia = math.sqrt((self.x - atom.x) ** 2 + (self.y - atom.y) ** 2)
                        if distancia < (self.raio + atom.raio):
                            # Se os átomos estão muito próximos, mova-os para longe um do outro
                            angulo = math.atan2(self.y - atom.y, self.x - atom.x)
                            nova_x = atom.x + (self.raio + atom.raio) * math.cos(angulo)
                            nova_y = atom.y + (self.raio + atom.raio) * math.sin(angulo)
                            self.x, self.y = nova_x, nova_y

    def eventos(self):
        posicao_mouse = pygame.mouse.get_pos()
        if eventos.type == pygame.MOUSEBUTTONDOWN:
            if self.retangulo.collidepoint(posicao_mouse):
                self.movendo = True
        elif eventos.type == pygame.MOUSEBUTTONUP:
            self.movendo = False


def img(imagem, x, y, width, height):
    image = pygame.image.load(imagem)
    redimensionada = pygame.transform.scale(image, (width, height))
    tela.blit(redimensionada, (x, y))


class Botao:
    def __init__(self, x, y, width, height, cor, b_r):
        self.retangulo = pygame.Rect(x, y, width, height)
        self.cor = cor
        self.b_r = b_r
        self.centro = self.retangulo.center

    def draw(self):
        pygame.draw.rect(tela, self.cor, self.retangulo, border_radius=self.b_r)

    def funcao(self, f, t):
        global acertos
        posicao_mouse = pygame.mouse.get_pos()
        if eventos.type == pygame.MOUSEBUTTONDOWN and ative_events[f]:
            if self.retangulo.collidepoint(posicao_mouse):
                telas[f] = False
                telas[t] = True
                ative_events[f] = False
                if t != 4 and tela_atual != 4:
                    acertos = 0


info = pygame.display.Info()
largura = info.current_w
altura = info.current_h
escala_x = largura / 1536
escala_y = altura / 854
tela = pygame.display.set_mode((largura, altura))

fonte = pygame.font.Font(None, int(36 * escala_x))
fonte3 = pygame.font.Font(None, int(50 * escala_x))
questao = 0
questao_2 = 0
questao_ligacao = 0
proxima_fase = 0
cor_rect = ["#1EBDBC", "#1EBDBC", "#1EBDBC"]
acertos = 0
acertos_fase1 = 0
acertos_fase2 = 0
acertos_fase3 = 0
acertos_fase4 = 0
acertos_fase5 = 0

carrega_atomo = False

c_retangulo1 = pygame.Rect(500 * escala_x, 700 * escala_y, 10 * escala_x, 10 * escala_y)
c_retangulo2 = pygame.Rect(800 * escala_x, 400 * escala_y, 10 * escala_x, 10 * escala_y)
c_retangulo3 = pygame.Rect(1100 * escala_x, 700 * escala_y, 10 * escala_x, 10 * escala_y)
c_retangulo4 = pygame.Rect(1100 * escala_x, 500 * escala_y, 10 * escala_x, 10 * escala_y)

atomo_hidrogenio = Atomo(1150 * escala_x, 760 * escala_y, "#5DF997", 80 * escala_x, "hidrogenio")
atomo_hidrogenio2 = Atomo(960 * escala_x, 760 * escala_y, "#5DF997", 80 * escala_x, "hidrogenio")
atomo_hidrogenio3 = Atomo(600 * escala_x, 760 * escala_y, "#5DF997", 80 * escala_x, "hidrogenio")
atomo_oxigenio = Atomo(780 * escala_x, 760 * escala_y, "orange", 80 * escala_x, "oxigenio")
atomo_oxigenio2 = Atomo(500 * escala_x, 760 * escala_y, "orange", 80 * escala_x, "oxigenio")
atomo_oxigenio3 = Atomo(700 * escala_x, 760 * escala_y, "orange", 80 * escala_x, "oxigenio")
atomo_nitrogenio = Atomo(800 * escala_x, 760 * escala_y, "orange", 80 * escala_x, "nitrogenio")
atomo_nitrogenio2 = Atomo(800 * escala_x, 760 * escala_y, "orange", 80 * escala_x, "nitrogenio")
atomo_carbono = Atomo(300 * escala_x, 760 * escala_y, "#5DF997", 80 * escala_x, "carbono")
atomo_fluor = Atomo(300 * escala_x, 760 * escala_y, "#5DF997", 80 * escala_x, "fluor")
atomo_fluor2 = Atomo(300 * escala_x, 760 * escala_y, "#5DF997", 80 * escala_x, "fluor")
atomo_fluor3 = Atomo(300 * escala_x, 760 * escala_y, "#5DF997", 80 * escala_x, "fluor")
atomo_boro = Atomo(300 * escala_x, 760 * escala_y, "#5DF997", 80 * escala_x, "boro")
atomo_selenio = Atomo(300 * escala_x, 760 * escala_y, "#5DF997", 80 * escala_x, "selenio")
atomo_fosforo = Atomo(300 * escala_x, 760 * escala_y, "#5DF997", 80 * escala_x, "fosforo")
atomo_enxofre = Atomo(300 * escala_x, 760 * escala_y, "#5DF997", 80 * escala_x, "enxofre")
atomo_enxofre2 = Atomo(300 * escala_x, 760 * escala_y, "#5DF997", 80 * escala_x, "enxofre")
atomo_cloro = Atomo(600 * escala_x, 760 * escala_y, "#5DF997", 80 * escala_x, "cloro")
atomo_cloro2 = Atomo(960 * escala_x, 760 * escala_y, "#5DF997", 80 * escala_x, "cloro")
todos_atomos = [atomo_hidrogenio, atomo_hidrogenio2, atomo_hidrogenio3, atomo_oxigenio, atomo_oxigenio2,
                atomo_oxigenio3, atomo_nitrogenio, atomo_nitrogenio2, atomo_carbono, atomo_fluor, atomo_fluor2,
                atomo_fluor3, atomo_boro, atomo_selenio, atomo_fosforo, atomo_enxofre, atomo_enxofre2, atomo_cloro,
                atomo_cloro2
                ]

atomos = [atomo_oxigenio, atomo_hidrogenio, atomo_hidrogenio2]
atomos2 = [atomo_carbono, atomo_oxigenio, atomo_oxigenio2]
atomos3 = [atomo_oxigenio, atomo_oxigenio2]
atomos4 = [atomo_enxofre, atomo_oxigenio, atomo_oxigenio2]
atomos5 = [atomo_nitrogenio, atomo_hidrogenio3, atomo_hidrogenio2, atomo_hidrogenio]
atomos6 = [atomo_hidrogenio, atomo_hidrogenio2]
atomos7 = [atomo_hidrogenio, atomo_hidrogenio2, atomo_enxofre]
atomos8 = [atomo_oxigenio3, atomo_oxigenio2, atomo_oxigenio]
atomos9 = [atomo_cloro, atomo_cloro2]
atomos10 = [atomo_enxofre2, atomo_enxofre, atomo_carbono]
atomos11 = [atomo_boro, atomo_fluor, atomo_fluor2, atomo_fluor3]
atomos12 = [atomo_nitrogenio, atomo_nitrogenio2]
atomos13 = [atomo_hidrogenio, atomo_carbono, atomo_nitrogenio]
atomos14 = [atomo_fosforo, atomo_hidrogenio, atomo_hidrogenio2, atomo_hidrogenio3]
atomos15 = [atomo_hidrogenio, atomo_hidrogenio2, atomo_selenio]

lista_atomos_atomos = [atomos, atomos2, atomos3, atomos4, atomos5, atomos6, atomos7, atomos8, atomos9, atomos10,
                       atomos11, atomos12, atomos13, atomos14, atomos15]


class C_inicio:
    def __init__(self):
        b_jogar.draw()
        b_teoria.draw()
        b_opcao.draw()
        fundo1 = img("imagens/1.png", 0, 0, largura, altura)
        robo = img("imagens/robo.png", -20 * escala_x, 70 * escala_y, 500 * escala_x, 500 * escala_y)


class C_jogar:
    def __init__(self):
        pass

    def aparece(self):
        b_opcao2.draw()
        b_fase.draw()
        b_fase2.draw()
        b_fase3.draw()
        b_fase4.draw()
        b_fase5.draw()
        b_voltar_fase.draw()
        retangulo_jogar = pygame.draw.ellipse(tela, "black", rect_jogar)
        fundo = img("imagens/2.png", 0, 0, largura, altura)
        indice_acertos_fase1 = fonte.render(str(acertos_fase1) + "/8", True, "black")
        indice_acertos_fase2 = fonte.render(str(acertos_fase2) + "/8", True, "black")
        indice_acertos_fase3 = fonte.render(str(acertos_fase3) + "/8", True, "black")
        indice_acertos_fase4 = fonte.render(str(acertos_fase4) + "/8", True, "black")
        indice_acertos_fase5 = fonte.render(str(acertos_fase5) + "/8", True, "black")

        tela.blit(indice_acertos_fase1, (387 * escala_x, 460 * escala_y))
        tela.blit(indice_acertos_fase2, (755 * escala_x, 460 * escala_y))
        tela.blit(indice_acertos_fase3, (1114 * escala_x, 460 * escala_y))
        tela.blit(indice_acertos_fase4, (550 * escala_x, 700 * escala_y))
        tela.blit(indice_acertos_fase5, (954 * escala_x, 700 * escala_y))

    def eventos(self):
        posicao_mouse = pygame.mouse.get_pos()
        if b_fase.retangulo.collidepoint(posicao_mouse):
            pass



class C_jogo1:
    def __init__(self):
        pass

    def aparece(self):
        global questao_ligacao
        global questao_2
        global questao
        global c_retangulo1
        global c_retangulo2
        global c_retangulo3
        global c_retangulo4
        global atomo_hidrogenio
        global atomo_hidrogenio2
        global atomo_hidrogenio3
        global atomo_oxigenio
        global atomo_oxigenio2
        global atomo_oxigenio3
        global atomo_nitrogenio
        global atomo_nitrogenio2
        global atomo_carbono
        global atomo_fluor
        global atomo_fluor2
        global atomo_fluor3
        global atomo_boro
        global atomo_selenio
        global atomo_fosforo
        global atomo_enxofre
        global atomo_enxofre2
        global atomo_cloro
        global atomo_cloro2
        global carrega_atomo
        if questao_ligacao % 2 == 0:

            global acertos_fase1
            ative_events[2] = True
            if questao < 5:
                y = 40 * escala_y
                pergunta = quebra_linhas(lista_perguntas[questao], 1200 * escala_x)
                b_opcaojogo1.draw()
                fundo = img("imagens/6.png", 0, 0, largura, altura)
                self.cabeca_robo = img("imagens/cabeca do robo.png", 1250 * escala_x, 25 * escala_y, 270 * escala_x,
                                       270 * escala_y)

                if not mostrar_dica:
                    b_ajuda_sim.draw()
                    boa_sorte = fonte.render("Quer ajuda?", True, "Black")
                    tela.blit(boa_sorte, (1300 * escala_x, 240 * escala_y))
                    tela.blit(texto_quero_ajuda, (1335 * escala_x, 280 * escala_y))
                if proxima_fase == 1:
                    b_proximo.draw()
                    tela.blit(texto_proximo, (1325 * escala_x, 718 * escala_y))
                for i, retangulo in enumerate(retangulos):
                    pygame.draw.rect(tela, cor_rect[i], retangulo)
                    texto = fonte.render(lista_opcoes[questao][i], True, "black")
                    width, height = fonte.size(lista_opcoes[questao][i])
                    tela.blit(texto,
                              (retangulo.x + (469.5 * escala_x - width / 2), retangulo.y + (80 * escala_y - height)))

                for linha in pergunta:
                    texto = fonte2.render(linha, True, "black")
                    tela.blit(texto, (160 * escala_x, y * escala_y))
                    y += texto.get_height() + (30 * escala_y)

                if mostrar_dica:
                    dica = fonte.render("D: " + dicas[questao], True, "black")
                    tela.blit(dica, (200 * escala_x, 200 * escala_y))

            if questao == 5:
                questao = 0
                questao_2 = 0
                questao_ligacao = 0
                telas[2] = False
                telas[6] = True
                ative_events[2] = False
                ative_events[6] = True
                acertos_fase1 = acertos
        elif questao_ligacao % 2 != 0:

            if questao_2 == 0:
                if carrega_atomo:
                    atomo_oxigenio.x, atomo_oxigenio.y = 1150 * escala_x, 760 * escala_y
                    atomo_hidrogenio.x, atomo_hidrogenio.y = 960 * escala_x, 760 * escala_y
                    atomo_hidrogenio2.x, atomo_hidrogenio2.y = 770 * escala_x, 760 * escala_y
                    carrega_atomo = False
                self.retangulo1 = pygame.draw.rect(tela, "black", c_retangulo1, 0)
                self.retangulo2 = pygame.draw.rect(tela, "black", c_retangulo2, 0)
                self.retangulo3 = pygame.draw.rect(tela, "black", c_retangulo3, 0)
                fundo = img("imagens/q1.png", 0, 0, largura, altura)
                b_concluir.draw()
                tela.blit(texto_proximo, (1325 * escala_x, 718 * escala_y))

                c_retangulo1 = pygame.Rect(530 * escala_x, 600 * escala_y, 10, 10)
                c_retangulo2 = pygame.Rect(770 * escala_x, 360 * escala_y, 10, 10)
                c_retangulo3 = pygame.Rect(1000 * escala_x, 600 * escala_y, 10, 10)


                atomo_oxigenio.draw()
                atomo_hidrogenio.draw()
                atomo_hidrogenio2.draw()
                atomo_oxigenio.update()
                atomo_hidrogenio.update()
                atomo_hidrogenio2.update()
            elif questao_2 == 1:
                if carrega_atomo:
                    atomo_oxigenio.x, atomo_oxigenio.y = 1150 * escala_x, 760 * escala_y
                    atomo_oxigenio2.x, atomo_oxigenio2.y = 960 * escala_x, 760 * escala_y
                    atomo_carbono.x, atomo_carbono.y = 770 * escala_x, 760 * escala_y
                    atomo_carbono.cor = "#5DF997"
                    carrega_atomo = False
                c_retangulo1 = pygame.Rect(300 * escala_x, 440 * escala_y, 10, 10)
                c_retangulo2 = pygame.Rect(800 * escala_x, 440 * escala_y, 10, 10)
                c_retangulo3 = pygame.Rect(1200 * escala_x, 440 * escala_y, 10, 10)
                self.retangulo1 = pygame.draw.rect(tela, "black", c_retangulo1, 0)
                self.retangulo2 = pygame.draw.rect(tela, "black", c_retangulo2, 0)
                self.retangulo3 = pygame.draw.rect(tela, "black", c_retangulo3, 0)
                fundo = img("imagens/q2.png", 0, 0, largura, altura)
                b_concluir.draw()
                tela.blit(texto_proximo, (1325 * escala_x, 718 * escala_y))


                atomo_oxigenio.draw()
                atomo_oxigenio2.draw()
                atomo_carbono.draw()
                atomo_oxigenio.update()
                atomo_oxigenio2.update()
                atomo_carbono.update()
            elif questao_2 == 2:
                if carrega_atomo:
                    atomo_oxigenio.x, atomo_oxigenio.y = 1150 * escala_x, 760 * escala_y
                    atomo_oxigenio2.x, atomo_hidrogenio2.y = 960 * escala_x, 760 * escala_y
                    carrega_atomo = False
                c_retangulo1 = pygame.Rect(500 * escala_x, 440 * escala_y, 10, 10)
                c_retangulo2 = pygame.Rect(1000 * escala_x, 440 * escala_y, 10, 10)
                self.retangulo1 = pygame.draw.rect(tela, "black", c_retangulo1, 0)
                self.retangulo2 = pygame.draw.rect(tela, "black", c_retangulo2, 0)

                fundo = img("imagens/q3.png", 0, 0, largura, altura)
                b_concluir.draw()
                tela.blit(texto_proximo, (1325 * escala_x, 718 * escala_y))


                atomo_oxigenio.draw()
                atomo_oxigenio2.draw()
                atomo_oxigenio.update()
                atomo_oxigenio2.update()

    def evento(self):
        global questao
        global proxima_fase
        global cor_rect
        global acertos
        global mostrar_dica
        global questao_ligacao
        global questao_2
        global carrega_atomo
        posicao_mouse = pygame.mouse.get_pos()
        if questao_ligacao % 2 == 0:
            if eventos.type == pygame.MOUSEBUTTONDOWN:
                if telas[2] and ative_events[2]:
                    for i, resposta in enumerate(retangulos):
                        if cor_rect == ["#1EBDBC", "#1EBDBC", "#1EBDBC"]:
                            if retangulos[i].collidepoint(posicao_mouse):
                                if lista_opcoes[questao][i] == respostas_corretas[questao]:
                                    cor_rect[i] = "darkgreen"
                                    som_acerto.play()
                                    acertos += 1
                                else:
                                    cor_rect[i] = "red"
                                    som_erro.play()
                                proxima_fase += 1
                    if proxima_fase == 1:
                        if b_proximo.retangulo.collidepoint(posicao_mouse):
                            questao_ligacao += 1
                            carrega_atomo = True

                            proxima_fase = 0
                            mostrar_dica = False
                            cor_rect = ["#1EBDBC", "#1EBDBC", "#1EBDBC"]
                    if b_ajuda_sim.retangulo.collidepoint(posicao_mouse):
                        mostrar_dica = True
        elif questao_ligacao % 2 != 0:
            if questao_2 == 0:

                atomo_oxigenio.eventos()
                atomo_hidrogenio.eventos()
                atomo_hidrogenio2.eventos()
            elif questao_2 == 1:
                atomo_oxigenio.eventos()
                atomo_oxigenio2.eventos()
                atomo_carbono.eventos()
            elif questao_2 == 2:
                atomo_oxigenio.eventos()
                atomo_oxigenio2.eventos()

            elif questao_2 == 3 or questao_2 == 4:
                questao_ligacao += 1
                questao += 1

            if eventos.type == pygame.MOUSEBUTTONDOWN:
                primeiro_atomo = None
                segundo_atomo = None
                terceiro_atomo = None
                quarto_atomo = None
                if b_concluir.retangulo.collidepoint(posicao_mouse):
                    for atom in lista_atomos_atomos[questao_2]:
                        if atom.retangulo.collidepoint(c_retangulo1.x, c_retangulo1.y):
                            primeiro_atomo = atom.elemento
                            print("Primeiro:" + primeiro_atomo)
                        elif atom.retangulo.collidepoint(c_retangulo2.x, c_retangulo2.y):
                            segundo_atomo = atom.elemento
                            print("Segundo:" + segundo_atomo)
                        elif atom.retangulo.collidepoint(c_retangulo3.x, c_retangulo3.y):
                            terceiro_atomo = atom.elemento
                            print("Terceiro:" + terceiro_atomo)
                        elif atom.retangulo.collidepoint(c_retangulo4.x, c_retangulo4.y):
                            quarto_atomo = atom.elemento
                            print("quarto:" + quarto_atomo)

                    resposta_dada = [primeiro_atomo, segundo_atomo, terceiro_atomo, quarto_atomo]
                    if resposta_dada == lista_resposta_ligacoes[questao_2]:
                        som_acerto.play()
                        acertos += 1
                    else:
                        som_erro.play()
                    questao += 1
                    questao_2 += 1
                    questao_ligacao += 1


class C_jogo2:
    def __init__(self):
        pass

    def aparece(self):
        global questao_ligacao
        global questao_2
        global questao
        global acertos_fase2
        global c_retangulo1
        global c_retangulo2
        global c_retangulo3
        global c_retangulo4
        global atomo_hidrogenio
        global atomo_hidrogenio2
        global atomo_hidrogenio3
        global atomo_oxigenio
        global atomo_oxigenio2
        global atomo_oxigenio3
        global atomo_nitrogenio
        global atomo_nitrogenio2
        global atomo_carbono
        global atomo_fluor
        global atomo_fluor2
        global atomo_fluor3
        global atomo_boro
        global atomo_selenio
        global atomo_fosforo
        global atomo_enxofre
        global atomo_enxofre2
        global atomo_cloro
        global atomo_cloro2
        global carrega_atomo
        if questao_ligacao % 2 == 0:

            ative_events[5] = True
            if questao < 5:
                y = 40 * escala_y
                pergunta = quebra_linhas(lista_perguntas[questao + 5], 1200 * escala_x)
                b_opcaojogo1.draw()
                fundo = img("imagens/6.png", 0, 0, largura, altura)
                self.cabeca_robo = img("imagens/cabeca do robo.png", 1250 * escala_x, 25 * escala_y, 270 * escala_x,
                                       270 * escala_y)
                # retangulo_cabeca.draw()
                if not mostrar_dica:
                    b_ajuda_sim.draw()
                    boa_sorte = fonte.render("Quer ajuda?", True, "Black")
                    tela.blit(boa_sorte, (1300 * escala_x, 240 * escala_y))
                    tela.blit(texto_quero_ajuda, (1335 * escala_x, 280 * escala_y))
                if proxima_fase == 1:
                    b_proximo.draw()
                    tela.blit(texto_proximo, (1325 * escala_x, 718 * escala_y))
                for i, retangulo in enumerate(retangulos):
                    pygame.draw.rect(tela, cor_rect[i], retangulo)
                    texto = fonte.render(lista_opcoes[questao + 5][i], True, "black")
                    width, height = fonte.size(lista_opcoes[questao + 5][i])
                    tela.blit(texto,
                              (retangulo.x + (469.5 * escala_x - width / 2), retangulo.y + (80 * escala_y - height)))

                for linha in pergunta:
                    texto = fonte2.render(linha, True, "black")
                    tela.blit(texto, (160 * escala_x, y * escala_y))
                    y += texto.get_height() + (30 * escala_y)

                if mostrar_dica:
                    dica = fonte.render("D: " + dicas[questao + 5], True, "black")
                    tela.blit(dica, (200 * escala_x, 200 * escala_y))

            if questao == 5:
                questao = 0
                questao_2 = 0
                questao_ligacao = 0
                telas[5] = False
                telas[6] = True
                ative_events[5] = False
                ative_events[6] = True
                acertos_fase2 = acertos
        elif questao_ligacao % 2 != 0:


            if questao_2 == 0:
                if carrega_atomo:
                    atomo_oxigenio.x, atomo_oxigenio.y = 1150 * escala_x, 760 * escala_y
                    atomo_oxigenio2.x, atomo_oxigenio2.y = 960 * escala_x, 760 * escala_y
                    atomo_enxofre.x, atomo_enxofre.y = 770 * escala_x, 760 * escala_y
                    atomo_enxofre.cor = "#5DF997"
                    carrega_atomo = False
                self.retangulo1 = pygame.draw.rect(tela, "black", c_retangulo1, 0)
                self.retangulo2 = pygame.draw.rect(tela, "black", c_retangulo2, 0)
                self.retangulo3 = pygame.draw.rect(tela, "black", c_retangulo3, 0)
                fundo = img("imagens/q4.png", 0, 0, largura, altura)
                b_concluir.draw()
                tela.blit(texto_proximo, (1325 * escala_x, 718 * escala_y))

                c_retangulo1 = pygame.Rect(530 * escala_x, 600 * escala_y, 10, 10)
                c_retangulo2 = pygame.Rect(770 * escala_x, 360 * escala_y, 10, 10)
                c_retangulo3 = pygame.Rect(1000 * escala_x, 600 * escala_y, 10, 10)


                atomo_oxigenio.draw()
                atomo_oxigenio2.draw()
                atomo_enxofre.draw()
                atomo_oxigenio.update()
                atomo_oxigenio2.update()
                atomo_enxofre.update()

            elif questao_2 == 1:
                if carrega_atomo:
                    atomo_hidrogenio.x, atomo_hidrogenio.y = 1150 * escala_x, 760 * escala_y
                    atomo_hidrogenio2.x, atomo_hidrogenio2.y = 960 * escala_x, 760 * escala_y
                    atomo_hidrogenio3.x, atomo_hidrogenio3.y = 770 * escala_x, 760 * escala_y
                    atomo_nitrogenio.x, atomo_nitrogenio.y = 580 * escala_x, 760 * escala_y
                    atomo_nitrogenio.cor = "orange"
                    carrega_atomo = False
                self.retangulo1 = pygame.draw.rect(tela, "black", c_retangulo1, 0)
                self.retangulo2 = pygame.draw.rect(tela, "black", c_retangulo2, 0)
                self.retangulo3 = pygame.draw.rect(tela, "black", c_retangulo3, 0)
                self.retangulo4 = pygame.draw.rect(tela, "black", c_retangulo4, 0)
                fundo = img("imagens/q5.png", 0, 0, largura, altura)
                b_concluir.draw()
                tela.blit(texto_proximo, (1325 * escala_x, 718 * escala_y))

                c_retangulo1 = pygame.Rect(530 * escala_x, 600 * escala_y, 10 * escala_x, 10 * escala_y)
                c_retangulo2 = pygame.Rect(770 * escala_x, 340 * escala_y, 10 * escala_x, 10 * escala_y)
                c_retangulo3 = pygame.Rect(770 * escala_x, 700 * escala_y, 10 * escala_x, 10 * escala_y)
                c_retangulo4 = pygame.Rect(1000 * escala_x, 600 * escala_y, 10 * escala_x, 10 * escala_y)


                atomo_hidrogenio.draw()
                atomo_hidrogenio2.draw()
                atomo_hidrogenio3.draw()
                atomo_nitrogenio.draw()
                atomo_hidrogenio.update()
                atomo_hidrogenio2.update()
                atomo_hidrogenio3.update()
                atomo_nitrogenio.update()

            elif questao_2 == 2:
                if carrega_atomo:
                    atomo_hidrogenio.x, atomo_hidrogenio.y = 1150 * escala_x, 760 * escala_y
                    atomo_hidrogenio2.x, atomo_hidrogenio2.y = 960 * escala_x, 760 * escala_y
                    carrega_atomo = False
                c_retangulo1 = pygame.Rect(500 * escala_x, 440 * escala_y, 10, 10)
                c_retangulo2 = pygame.Rect(1000 * escala_x, 440 * escala_y, 10, 10)
                self.retangulo1 = pygame.draw.rect(tela, "black", c_retangulo1, 0)
                self.retangulo2 = pygame.draw.rect(tela, "black", c_retangulo2, 0)

                fundo = img("imagens/q6.png", 0, 0, largura, altura)
                b_concluir.draw()
                tela.blit(texto_proximo, (1325 * escala_x, 718 * escala_y))


                atomo_hidrogenio.draw()
                atomo_hidrogenio2.draw()
                atomo_hidrogenio.update()
                atomo_hidrogenio2.update()

    def evento(self):
        global questao
        global proxima_fase
        global cor_rect
        global acertos
        global mostrar_dica
        global questao_ligacao
        global questao_2
        global carrega_atomo
        posicao_mouse = pygame.mouse.get_pos()
        if questao_ligacao % 2 == 0:
            if eventos.type == pygame.MOUSEBUTTONDOWN:
                if telas[5] and ative_events[5]:
                    for i, resposta in enumerate(retangulos):
                        if cor_rect == ["#1EBDBC", "#1EBDBC", "#1EBDBC"]:
                            if retangulos[i].collidepoint(posicao_mouse):
                                if lista_opcoes[questao + 5][i] == respostas_corretas[questao + 5]:
                                    cor_rect[i] = "darkgreen"
                                    som_acerto.play()
                                    acertos += 1
                                else:
                                    cor_rect[i] = "red"
                                    som_erro.play()
                                proxima_fase += 1
                    if proxima_fase == 1:
                        if b_proximo.retangulo.collidepoint(posicao_mouse):
                            questao_ligacao += 1
                            carrega_atomo = True
                            proxima_fase = 0
                            mostrar_dica = False
                            cor_rect = ["#1EBDBC", "#1EBDBC", "#1EBDBC"]
                    if b_ajuda_sim.retangulo.collidepoint(posicao_mouse):
                        mostrar_dica = True
        elif questao_ligacao % 2 != 0:
            if questao_2 == 0:
                atomo_oxigenio.eventos()
                atomo_oxigenio2.eventos()
                atomo_enxofre.eventos()
            elif questao_2 == 1:
                atomo_nitrogenio.eventos()
                atomo_hidrogenio.eventos()
                atomo_hidrogenio2.eventos()
                atomo_hidrogenio3.eventos()
            elif questao_2 == 2:
                atomo_hidrogenio.eventos()
                atomo_hidrogenio2.eventos()

            elif questao_2 == 3 or questao_2 == 4:
                questao_ligacao += 1
                questao += 1

            if eventos.type == pygame.MOUSEBUTTONDOWN:
                primeiro_atomo = None
                segundo_atomo = None
                terceiro_atomo = None
                quarto_atomo = None
                if b_concluir.retangulo.collidepoint(posicao_mouse):
                    for atom in lista_atomos_atomos[questao_2 + 3]:
                        if atom.retangulo.collidepoint(c_retangulo1.x, c_retangulo1.y):
                            primeiro_atomo = atom.elemento
                            print("Primeiro:" + primeiro_atomo)
                        elif atom.retangulo.collidepoint(c_retangulo2.x, c_retangulo2.y):
                            segundo_atomo = atom.elemento
                            print("Segundo:" + segundo_atomo)
                        elif atom.retangulo.collidepoint(c_retangulo3.x, c_retangulo3.y):
                            terceiro_atomo = atom.elemento
                            print("Terceiro:" + terceiro_atomo)
                        elif atom.retangulo.collidepoint(c_retangulo4.x, c_retangulo4.y):
                            quarto_atomo = atom.elemento
                            print("quarto:" + quarto_atomo)

                    resposta_dada = [primeiro_atomo, segundo_atomo, terceiro_atomo, quarto_atomo]
                    if resposta_dada == lista_resposta_ligacoes[questao_2 + 3]:
                        som_acerto.play()
                        acertos += 1
                    else:
                        som_erro.play()
                    questao += 1
                    questao_2 += 1
                    questao_ligacao += 1


class C_jogo3:
    def __init__(self):
        pass

    def aparece(self):
        global questao_ligacao
        global questao_2
        global questao
        global acertos_fase3
        global c_retangulo1
        global c_retangulo2
        global c_retangulo3
        global c_retangulo4
        global atomo_hidrogenio
        global atomo_hidrogenio2
        global atomo_hidrogenio3
        global atomo_oxigenio
        global atomo_oxigenio2
        global atomo_oxigenio3
        global atomo_nitrogenio
        global atomo_nitrogenio2
        global atomo_carbono
        global atomo_fluor
        global atomo_fluor2
        global atomo_fluor3
        global atomo_boro
        global atomo_selenio
        global atomo_fosforo
        global atomo_enxofre
        global atomo_enxofre2
        global atomo_cloro
        global atomo_cloro2
        global carrega_atomo
        if questao_ligacao % 2 == 0:
            ative_events[7] = True
            if questao < 5:
                y = 40 * escala_y
                pergunta = quebra_linhas(lista_perguntas[questao + 10], 1200 * escala_x)
                b_opcaojogo1.draw()
                fundo = img("imagens/6.png", 0, 0, largura, altura)
                self.cabeca_robo = img("imagens/cabeca do robo.png", 1250 * escala_x, 25 * escala_y, 270 * escala_x,
                                       270 * escala_y)
                # retangulo_cabeca.draw()
                if not mostrar_dica:
                    b_ajuda_sim.draw()
                    boa_sorte = fonte.render("Quer ajuda?", True, "Black")
                    tela.blit(boa_sorte, (1300 * escala_x, 240 * escala_y))
                    tela.blit(texto_quero_ajuda, (1335 * escala_x, 280 * escala_y))
                if proxima_fase == 1:
                    b_proximo.draw()
                    tela.blit(texto_proximo, (1325 * escala_x, 718 * escala_y))
                for i, retangulo in enumerate(retangulos):
                    pygame.draw.rect(tela, cor_rect[i], retangulo)
                    texto = fonte.render(lista_opcoes[questao + 10][i], True, "black")
                    width, height = fonte.size(lista_opcoes[questao + 10][i])
                    tela.blit(texto,
                              (retangulo.x + (469.5 * escala_x - width / 2), retangulo.y + (80 * escala_y - height)))

                for linha in pergunta:
                    texto = fonte2.render(linha, True, "black")
                    tela.blit(texto, (160 * escala_x, y * escala_y))
                    y += texto.get_height() + (30 * escala_y)

                if mostrar_dica:
                    dica = fonte.render("D: " + dicas[questao + 10], True, "black")
                    tela.blit(dica, (200 * escala_x, 200 * escala_y))

            if questao == 5:
                questao = 0
                questao_2 = 0
                questao_ligacao = 0
                telas[7] = False
                telas[6] = True
                ative_events[7] = False
                ative_events[6] = True
                acertos_fase3 = acertos
        elif questao_ligacao % 2 != 0:

            if questao_2 == 0:
                if carrega_atomo:
                    atomo_hidrogenio.x, atomo_hidrogenio.y = 1150 * escala_x, 760 * escala_y
                    atomo_hidrogenio2.x, atomo_hidrogenio2.y = 960 * escala_x, 760 * escala_y
                    atomo_enxofre.x, atomo_enxofre.y = 770 * escala_x, 760 * escala_y
                    atomo_enxofre.cor = "orange"
                    carrega_atomo = False
                self.retangulo1 = pygame.draw.rect(tela, "black", c_retangulo1, 0)
                self.retangulo2 = pygame.draw.rect(tela, "black", c_retangulo2, 0)
                self.retangulo3 = pygame.draw.rect(tela, "black", c_retangulo3, 0)
                fundo = img("imagens/q7.png", 0, 0, largura, altura)
                b_concluir.draw()
                tela.blit(texto_proximo, (1325 * escala_x, 718 * escala_y))

                c_retangulo1 = pygame.Rect(530 * escala_x, 600 * escala_y, 10, 10)
                c_retangulo2 = pygame.Rect(770 * escala_x, 360 * escala_y, 10, 10)
                c_retangulo3 = pygame.Rect(1000 * escala_x, 600 * escala_y, 10, 10)


                atomo_hidrogenio.draw()
                atomo_hidrogenio2.draw()
                atomo_enxofre.draw()
                atomo_hidrogenio.update()
                atomo_hidrogenio2.update()
                atomo_enxofre.update()

            elif questao_2 == 1:
                if carrega_atomo:
                    atomo_oxigenio.x, atomo_oxigenio.y = 1150 * escala_x, 760 * escala_y
                    atomo_oxigenio2.x, atomo_oxigenio2.y = 960 * escala_x, 760 * escala_y
                    atomo_oxigenio3.x, atomo_oxigenio3.y = 770 * escala_x, 760 * escala_y
                    carrega_atomo = False
                self.retangulo1 = pygame.draw.rect(tela, "black", c_retangulo1, 0)
                self.retangulo2 = pygame.draw.rect(tela, "black", c_retangulo2, 0)
                self.retangulo3 = pygame.draw.rect(tela, "black", c_retangulo3, 0)
                fundo = img("imagens/q8.png", 0, 0, largura, altura)
                b_concluir.draw()
                tela.blit(texto_proximo, (1325 * escala_x, 718 * escala_y))

                c_retangulo1 = pygame.Rect(300 * escala_x, 440 * escala_y, 10, 10)
                c_retangulo2 = pygame.Rect(800 * escala_x, 440 * escala_y, 10, 10)
                c_retangulo3 = pygame.Rect(1200 * escala_x, 440 * escala_y, 10, 10)


                atomo_oxigenio.draw()
                atomo_oxigenio2.draw()
                atomo_oxigenio3.draw()
                atomo_oxigenio.update()
                atomo_oxigenio2.update()
                atomo_oxigenio3.update()

            elif questao_2 == 2:
                if carrega_atomo:
                    atomo_cloro.x, atomo_cloro.y = 1150 * escala_x, 760 * escala_y
                    atomo_cloro2.x, atomo_cloro2.y = 960 * escala_x, 760 * escala_y
                    atomo_cloro.cor = "orange"
                    atomo_cloro2.cor = "orange"
                    carrega_atomo = False
                c_retangulo1 = pygame.Rect(500 * escala_x, 440 * escala_y, 10, 10)
                c_retangulo2 = pygame.Rect(1000 * escala_x, 440 * escala_y, 10, 10)
                self.retangulo1 = pygame.draw.rect(tela, "black", c_retangulo1, 0)
                self.retangulo2 = pygame.draw.rect(tela, "black", c_retangulo2, 0)

                fundo = img("imagens/q9.png", 0, 0, largura, altura)
                b_concluir.draw()
                tela.blit(texto_proximo, (1325 * escala_x, 718 * escala_y))


                atomo_cloro.draw()
                atomo_cloro2.draw()
                atomo_cloro.update()
                atomo_cloro2.update()

    def evento(self):
        global questao
        global proxima_fase
        global cor_rect
        global acertos
        global mostrar_dica
        global questao_ligacao
        global questao_2
        global carrega_atomo
        posicao_mouse = pygame.mouse.get_pos()
        if questao_ligacao % 2 == 0:
            if eventos.type == pygame.MOUSEBUTTONDOWN:
                if telas[7] and ative_events[7]:
                    for i, resposta in enumerate(retangulos):
                        if cor_rect == ["#1EBDBC", "#1EBDBC", "#1EBDBC"]:
                            if retangulos[i].collidepoint(posicao_mouse):
                                if lista_opcoes[questao + 10][i] == respostas_corretas[questao + 10]:
                                    cor_rect[i] = "darkgreen"
                                    som_acerto.play()
                                    acertos += 1
                                else:
                                    cor_rect[i] = "red"
                                    som_erro.play()
                                proxima_fase += 1
                    if proxima_fase == 1:
                        if b_proximo.retangulo.collidepoint(posicao_mouse):
                            questao_ligacao += 1
                            carrega_atomo = True

                            proxima_fase = 0
                            mostrar_dica = False
                            cor_rect = ["#1EBDBC", "#1EBDBC", "#1EBDBC"]
                    if b_ajuda_sim.retangulo.collidepoint(posicao_mouse):
                        mostrar_dica = True
        elif questao_ligacao % 2 != 0:
            if questao_2 == 0:
                atomo_hidrogenio.eventos()
                atomo_hidrogenio2.eventos()
                atomo_enxofre.eventos()
            elif questao_2 == 1:
                atomo_oxigenio.eventos()
                atomo_oxigenio2.eventos()
                atomo_oxigenio3.eventos()
            elif questao_2 == 2:
                atomo_cloro.eventos()
                atomo_cloro2.eventos()

            elif questao_2 == 3 or questao_2 == 4:
                questao_ligacao += 1
                questao += 1
            if eventos.type == pygame.MOUSEBUTTONDOWN:
                primeiro_atomo = None
                segundo_atomo = None
                terceiro_atomo = None
                quarto_atomo = None
                if b_concluir.retangulo.collidepoint(posicao_mouse):
                    for atom in lista_atomos_atomos[questao_2 + 6]:
                        if atom.retangulo.collidepoint(c_retangulo1.x, c_retangulo1.y):
                            primeiro_atomo = atom.elemento
                            print("Primeiro:" + primeiro_atomo)
                        elif atom.retangulo.collidepoint(c_retangulo2.x, c_retangulo2.y):
                            segundo_atomo = atom.elemento
                            print("Segundo:" + segundo_atomo)
                        elif atom.retangulo.collidepoint(c_retangulo3.x, c_retangulo3.y):
                            terceiro_atomo = atom.elemento
                            print("Terceiro:" + terceiro_atomo)
                        elif atom.retangulo.collidepoint(c_retangulo4.x, c_retangulo4.y):
                            quarto_atomo = atom.elemento
                            print("quarto:" + quarto_atomo)

                    resposta_dada = [primeiro_atomo, segundo_atomo, terceiro_atomo, quarto_atomo]
                    if resposta_dada == lista_resposta_ligacoes[questao_2 + 6]:
                        som_acerto.play()
                        acertos += 1
                    else:
                        som_erro.play()
                    questao += 1
                    questao_2 += 1
                    questao_ligacao += 1


class C_jogo4:
    def __init__(self):
        pass

    def aparece(self):
        global questao_ligacao
        global questao_2
        global questao
        global acertos_fase4
        global c_retangulo1
        global c_retangulo2
        global c_retangulo3
        global c_retangulo4
        global atomo_hidrogenio
        global atomo_hidrogenio2
        global atomo_hidrogenio3
        global atomo_oxigenio
        global atomo_oxigenio2
        global atomo_oxigenio3
        global atomo_nitrogenio
        global atomo_nitrogenio2
        global atomo_carbono
        global atomo_fluor
        global atomo_fluor2
        global atomo_fluor3
        global atomo_boro
        global atomo_selenio
        global atomo_fosforo
        global atomo_enxofre
        global atomo_enxofre2
        global atomo_cloro
        global atomo_cloro2
        global carrega_atomo
        global mostrar_dica
        if questao_ligacao % 2 == 0:
            ative_events[8] = True
            if questao < 5:
                y = 40 * escala_y
                pergunta = quebra_linhas(lista_perguntas[questao + 15], 1200 * escala_x)
                b_opcaojogo1.draw()
                fundo = img("imagens/6.png", 0, 0, largura, altura)
                self.cabeca_robo = img("imagens/cabeca do robo.png", 1250 * escala_x, 25 * escala_y, 270 * escala_x,
                                       270 * escala_y)
                # retangulo_cabeca.draw()
                if not mostrar_dica:
                    b_ajuda_sim.draw()
                    boa_sorte = fonte.render("Quer ajuda?", True, "Black")
                    tela.blit(boa_sorte, (1300 * escala_x, 240 * escala_y))
                    tela.blit(texto_quero_ajuda, (1335 * escala_x, 280 * escala_y))
                if proxima_fase == 1:
                    b_proximo.draw()
                    tela.blit(texto_proximo, (1325 * escala_x, 718 * escala_y))
                for i, retangulo in enumerate(retangulos):
                    pygame.draw.rect(tela, cor_rect[i], retangulo)
                    texto = fonte.render(lista_opcoes[questao + 15][i], True, "black")
                    width, height = fonte.size(lista_opcoes[questao + 15][i])
                    tela.blit(texto,
                              (retangulo.x + (469.5 * escala_x - width / 2), retangulo.y + (80 * escala_y - height)))

                for linha in pergunta:
                    texto = fonte2.render(linha, True, "black")
                    tela.blit(texto, (160 * escala_x, y * escala_y))
                    y += texto.get_height() + (30 * escala_y)

                if mostrar_dica:
                    dica = fonte.render("D: " + dicas[questao + 15], True, "black")
                    tela.blit(dica, (200 * escala_x, 200 * escala_y))

            if questao == 5:
                questao = 0
                questao_2 = 0
                questao_ligacao = 0
                mostrar_dica = False
                telas[8] = False
                telas[6] = True
                ative_events[8] = False
                ative_events[6] = True
                acertos_fase4 = acertos
        elif questao_ligacao % 2 != 0:


            if questao_2 == 0:
                if carrega_atomo:
                    atomo_carbono.x, atomo_carbono.y = 1150 * escala_x, 760 * escala_y
                    atomo_enxofre.x, atomo_enxofre.y = 960 * escala_x, 760 * escala_y
                    atomo_enxofre2.x, atomo_enxofre2.y = 600 * escala_x, 760 * escala_y
                    atomo_enxofre.cor = "orange"
                    atomo_enxofre2.cor = "orange"
                    atomo_carbono.cor = "#5DF997"
                    carrega_atomo = False
                fundo = img("imagens/q10.png", 0, 0, largura, altura)
                b_concluir.draw()
                tela.blit(texto_proximo, (1325 * escala_x, 718 * escala_y))

                c_retangulo1 = pygame.Rect(530 * escala_x, 600 * escala_y, 10, 10)
                c_retangulo2 = pygame.Rect(770 * escala_x, 360 * escala_y, 10, 10)
                c_retangulo3 = pygame.Rect(1000 * escala_x, 600 * escala_y, 10, 10)

                self.retangulo1 = pygame.draw.rect(tela, "black", c_retangulo1, 0)
                self.retangulo2 = pygame.draw.rect(tela, "black", c_retangulo2, 0)
                self.retangulo3 = pygame.draw.rect(tela, "black", c_retangulo3, 0)

                atomo_carbono.draw()
                atomo_enxofre.draw()
                atomo_enxofre2.draw()
                atomo_carbono.update()
                atomo_enxofre.update()
                atomo_enxofre2.update()


            elif questao_2 == 1:

                if carrega_atomo:
                    atomo_boro.x, atomo_carbono.y = 1150 * escala_x, 760 * escala_y
                    atomo_fluor.x, atomo_fluor.y = 960 * escala_x, 760 * escala_y
                    atomo_fluor2.x, atomo_fluor2.y = 770 * escala_x, 760 * escala_y
                    atomo_fluor3.x, atomo_fluor3.y = 580 * escala_x, 760 * escala_y
                    atomo_fluor.cor = "orange"
                    atomo_fluor2.cor = "orange"
                    atomo_fluor3.cor = "orange"
                    atomo_boro.cor = "#5DF997"
                    carrega_atomo = False
                self.retangulo1 = pygame.draw.rect(tela, "black", c_retangulo1, 0)
                self.retangulo2 = pygame.draw.rect(tela, "black", c_retangulo2, 0)
                self.retangulo3 = pygame.draw.rect(tela, "black", c_retangulo3, 0)
                self.retangulo4 = pygame.draw.rect(tela, "black", c_retangulo4, 0)

                fundo = img("imagens/q11.png", 0, 0, largura, altura)
                b_concluir.draw()
                tela.blit(texto_proximo, (1325 * escala_x, 718 * escala_y))

                c_retangulo1 = pygame.Rect(530 * escala_x, 600 * escala_y, 10 * escala_x, 10 * escala_y)
                c_retangulo2 = pygame.Rect(770 * escala_x, 290 * escala_y, 10 * escala_x, 10 * escala_y)
                c_retangulo3 = pygame.Rect(770 * escala_x, 480 * escala_y, 10 * escala_x, 10 * escala_y)
                c_retangulo4 = pygame.Rect(1000 * escala_x, 600 * escala_y, 10 * escala_x, 10 * escala_y)


                atomo_boro.draw()
                atomo_fluor.draw()
                atomo_fluor2.draw()
                atomo_fluor3.draw()
                atomo_boro.update()
                atomo_fluor.update()
                atomo_fluor2.update()
                atomo_fluor3.update()

            elif questao_2 == 2:
                if carrega_atomo:
                    atomo_nitrogenio.x, atomo_nitrogenio.y = 1150 * escala_x, 760 * escala_y
                    atomo_nitrogenio2.x, atomo_nitrogenio2.y = 960 * escala_x, 760 * escala_y
                    atomo_nitrogenio.cor = "#7C5FB4"
                    atomo_nitrogenio2.cor = "#7C5FB4"
                    carrega_atomo = False

                c_retangulo1 = pygame.Rect(500 * escala_x, 440 * escala_y, 10, 10)
                c_retangulo2 = pygame.Rect(1000 * escala_x, 440 * escala_y, 10, 10)
                self.retangulo1 = pygame.draw.rect(tela, "black", c_retangulo1, 0)
                self.retangulo2 = pygame.draw.rect(tela, "black", c_retangulo2, 0)

                fundo = img("imagens/q12.png", 0, 0, largura, altura)
                b_concluir.draw()
                tela.blit(texto_proximo, (1325 * escala_x, 718 * escala_y))


                atomo_nitrogenio.draw()
                atomo_nitrogenio2.draw()
                atomo_nitrogenio.update()
                atomo_nitrogenio2.update()

    def evento(self):
        global questao
        global proxima_fase
        global cor_rect
        global acertos
        global mostrar_dica
        global questao_ligacao
        global questao_2
        global carrega_atomo
        posicao_mouse = pygame.mouse.get_pos()
        if questao_ligacao % 2 == 0:
            if eventos.type == pygame.MOUSEBUTTONDOWN:
                if telas[8] and ative_events[8]:
                    for i, resposta in enumerate(retangulos):
                        if cor_rect == ["#1EBDBC", "#1EBDBC", "#1EBDBC"]:
                            if retangulos[i].collidepoint(posicao_mouse):
                                if lista_opcoes[questao + 15][i] == respostas_corretas[questao + 15]:
                                    cor_rect[i] = "darkgreen"
                                    som_acerto.play()
                                    acertos += 1
                                else:
                                    cor_rect[i] = "red"
                                    som_erro.play()
                                proxima_fase += 1
                    if proxima_fase == 1:
                        if b_proximo.retangulo.collidepoint(posicao_mouse):
                            questao_ligacao += 1
                            carrega_atomo = True
                            proxima_fase = 0
                            mostrar_dica = False
                            cor_rect = ["#1EBDBC", "#1EBDBC", "#1EBDBC"]
                    if b_ajuda_sim.retangulo.collidepoint(posicao_mouse):
                        mostrar_dica = True
        elif questao_ligacao % 2 != 0:
            if questao_2 == 0:
                atomo_carbono.eventos()
                atomo_enxofre.eventos()
                atomo_enxofre2.eventos()
            elif questao_2 == 1:
                atomo_boro.eventos()
                atomo_fluor.eventos()
                atomo_fluor2.eventos()
                atomo_fluor3.eventos()
            elif questao_2 == 2:
                atomo_nitrogenio.eventos()
                atomo_nitrogenio2.eventos()
            elif questao_2 == 3 or questao_2 == 4:
                questao_ligacao += 1
                questao += 1
            if eventos.type == pygame.MOUSEBUTTONDOWN:
                primeiro_atomo = None
                segundo_atomo = None
                terceiro_atomo = None
                quarto_atomo = None
                if b_concluir.retangulo.collidepoint(posicao_mouse):
                    for atom in lista_atomos_atomos[questao_2 + 9]:
                        if atom.retangulo.collidepoint(c_retangulo1.x, c_retangulo1.y):
                            primeiro_atomo = atom.elemento
                            print("Primeiro:" + primeiro_atomo)
                        elif atom.retangulo.collidepoint(c_retangulo2.x, c_retangulo2.y):
                            segundo_atomo = atom.elemento
                            print("Segundo:" + segundo_atomo)
                        elif atom.retangulo.collidepoint(c_retangulo3.x, c_retangulo3.y):
                            terceiro_atomo = atom.elemento
                            print("Terceiro:" + terceiro_atomo)
                        elif atom.retangulo.collidepoint(c_retangulo4.x, c_retangulo4.y):
                            quarto_atomo = atom.elemento
                            print("quarto:" + quarto_atomo)

                    resposta_dada = [primeiro_atomo, segundo_atomo, terceiro_atomo, quarto_atomo]
                    if resposta_dada == lista_resposta_ligacoes[questao_2 + 9]:
                        som_acerto.play()
                        acertos += 1
                    else:
                        som_erro.play()
                    questao += 1
                    questao_2 += 1
                    questao_ligacao += 1


class C_jogo5:
    def __init__(self):
        pass

    def aparece(self):
        global questao_ligacao
        global questao_2
        global questao
        global acertos_fase4
        global c_retangulo1
        global c_retangulo2
        global c_retangulo3
        global c_retangulo4
        global atomo_hidrogenio
        global atomo_hidrogenio2
        global atomo_hidrogenio3
        global atomo_oxigenio
        global atomo_oxigenio2
        global atomo_oxigenio3
        global atomo_nitrogenio
        global atomo_nitrogenio2
        global atomo_carbono
        global atomo_fluor
        global atomo_fluor2
        global atomo_fluor3
        global atomo_boro
        global atomo_selenio
        global atomo_fosforo
        global atomo_enxofre
        global atomo_enxofre2
        global atomo_cloro
        global atomo_cloro2
        global carrega_atomo
        global mostrar_dica
        if questao_ligacao % 2 == 0:
            ative_events[9] = True
            if questao < 5:
                y = 40 * escala_y
                pergunta = quebra_linhas(lista_perguntas[questao + 20], 1200 * escala_x)
                b_opcaojogo1.draw()
                fundo = img("imagens/6.png", 0, 0, largura, altura)
                self.cabeca_robo = img("imagens/cabeca do robo.png", 1250 * escala_x, 25 * escala_y, 270 * escala_x,
                                       270 * escala_y)
                if not mostrar_dica:
                    b_ajuda_sim.draw()
                    boa_sorte = fonte.render("Quer ajuda?", True, "Black")
                    tela.blit(boa_sorte, (1300 * escala_x, 240 * escala_y))
                    tela.blit(texto_quero_ajuda, (1335 * escala_x, 280 * escala_y))
                if proxima_fase == 1:
                    b_proximo.draw()
                    tela.blit(texto_proximo, (1325 * escala_x, 718 * escala_y))
                for i, retangulo in enumerate(retangulos):
                    pygame.draw.rect(tela, cor_rect[i], retangulo)
                    texto = fonte.render(lista_opcoes[questao + 20][i], True, "black")
                    width, height = fonte.size(lista_opcoes[questao + 20][i])
                    tela.blit(texto,
                              (retangulo.x + (469.5 * escala_x - width / 2), retangulo.y + (80 * escala_y - height)))

                for linha in pergunta:
                    texto = fonte2.render(linha, True, "black")
                    tela.blit(texto, (160 * escala_x, y * escala_y))
                    y += texto.get_height() + (30 * escala_y)

                if mostrar_dica:
                    dica = fonte.render("D: " + dicas[questao + 20], True, "black")
                    tela.blit(dica, (200 * escala_x, 200 * escala_y))

            if questao == 5:
                questao = 0
                questao_2 = 0
                questao_ligacao = 0
                mostrar_dica = False
                telas[9] = False
                telas[6] = True
                ative_events[9] = False
                ative_events[6] = True
                acertos_fase5 = acertos
        elif questao_ligacao % 2 != 0:


            if questao_2 == 0:
                if carrega_atomo:
                    atomo_carbono.x, atomo_carbono.y = 1150 * escala_x, 760 * escala_y
                    atomo_hidrogenio.x, atomo_hidrogenio.y = 960 * escala_x, 760 * escala_y
                    atomo_nitrogenio.x, atomo_nitrogenio.y = 600 * escala_x, 760 * escala_y
                    atomo_nitrogenio.cor = "#7C5FB4"
                    atomo_carbono.cor = "orange"
                    carrega_atomo = False
                self.retangulo1 = pygame.draw.rect(tela, "black", c_retangulo1, 0)
                self.retangulo2 = pygame.draw.rect(tela, "black", c_retangulo2, 0)
                self.retangulo3 = pygame.draw.rect(tela, "black", c_retangulo3, 0)
                fundo = img("imagens/q13.png", 0, 0, largura, altura)
                b_concluir.draw()
                tela.blit(texto_proximo, (1325 * escala_x, 718 * escala_y))

                c_retangulo1 = pygame.Rect(400 * escala_x, 440 * escala_y, 10, 10)
                c_retangulo2 = pygame.Rect(750 * escala_x, 440 * escala_y, 10, 10)
                c_retangulo3 = pygame.Rect(1100 * escala_x, 440 * escala_y, 10, 10)


                atomo_carbono.draw()
                atomo_hidrogenio.draw()
                atomo_nitrogenio.draw()
                atomo_carbono.update()
                atomo_hidrogenio.update()
                atomo_nitrogenio.update()


            elif questao_2 == 1:

                if carrega_atomo:
                    atomo_fosforo.x, atomo_fosforo.y = 1150 * escala_x, 760 * escala_y
                    atomo_hidrogenio.x, atomo_hidrogenio.y = 960 * escala_x, 760 * escala_y
                    atomo_hidrogenio2.x, atomo_hidrogenio2.y = 770 * escala_x, 760 * escala_y
                    atomo_hidrogenio3.x, atomo_hidrogenio3.y = 580 * escala_x, 760 * escala_y
                    atomo_fosforo.cor = "orange"
                    carrega_atomo = False

                self.retangulo1 = pygame.draw.rect(tela, "black", c_retangulo1, 0)
                self.retangulo2 = pygame.draw.rect(tela, "black", c_retangulo2, 0)
                self.retangulo3 = pygame.draw.rect(tela, "black", c_retangulo3, 0)
                self.retangulo4 = pygame.draw.rect(tela, "black", c_retangulo4, 0)
                fundo = img("imagens/q14.png", 0, 0, largura, altura)
                b_concluir.draw()
                tela.blit(texto_proximo, (1325 * escala_x, 718 * escala_y))
                c_retangulo1 = pygame.Rect(530 * escala_x, 600 * escala_y, 10 * escala_x, 10 * escala_y)
                c_retangulo2 = pygame.Rect(770 * escala_x, 340 * escala_y, 10 * escala_x, 10 * escala_y)
                c_retangulo3 = pygame.Rect(770 * escala_x, 700 * escala_y, 10 * escala_x, 10 * escala_y)
                c_retangulo4 = pygame.Rect(1000 * escala_x, 600 * escala_y, 10 * escala_x, 10 * escala_y)


                atomo_fosforo.draw()
                atomo_hidrogenio.draw()
                atomo_hidrogenio2.draw()
                atomo_hidrogenio3.draw()
                atomo_fosforo.update()
                atomo_hidrogenio.update()
                atomo_hidrogenio2.update()
                atomo_hidrogenio3.update()



            elif questao_2 == 2:
                if carrega_atomo:
                    atomo_hidrogenio.x, atomo_hidrogenio.y = 1150 * escala_x, 760 * escala_y
                    atomo_hidrogenio2.x, atomo_hidrogenio2.y = 960 * escala_x, 760 * escala_y
                    atomo_selenio.x, atomo_selenio.y = 770 * escala_x, 760 * escala_y
                    atomo_selenio.cor = "orange"
                    carrega_atomo = False

                c_retangulo1 = pygame.Rect(530 * escala_x, 600 * escala_y, 10, 10)
                c_retangulo2 = pygame.Rect(770 * escala_x, 360 * escala_y, 10, 10)
                c_retangulo3 = pygame.Rect(1000 * escala_x, 600 * escala_y, 10, 10)
                self.retangulo1 = pygame.draw.rect(tela, "black", c_retangulo1, 0)
                self.retangulo2 = pygame.draw.rect(tela, "black", c_retangulo2, 0)
                self.retangulo3 = pygame.draw.rect(tela, "black", c_retangulo3, 0)

                fundo = img("imagens/q15.png", 0, 0, largura, altura)
                b_concluir.draw()
                tela.blit(texto_proximo, (1325 * escala_x, 718 * escala_y))


                atomo_hidrogenio.draw()
                atomo_hidrogenio2.draw()
                atomo_selenio.draw()
                atomo_hidrogenio.update()
                atomo_hidrogenio2.update()
                atomo_selenio.update()

    def evento(self):
        global questao
        global proxima_fase
        global cor_rect
        global acertos
        global mostrar_dica
        global questao_ligacao
        global questao_2
        global carrega_atomo
        posicao_mouse = pygame.mouse.get_pos()
        if questao_ligacao % 2 == 0:
            if eventos.type == pygame.MOUSEBUTTONDOWN:
                if telas[9] and ative_events[9]:
                    for i, resposta in enumerate(retangulos):
                        if cor_rect == ["#1EBDBC", "#1EBDBC", "#1EBDBC"]:
                            if retangulos[i].collidepoint(posicao_mouse):
                                if lista_opcoes[questao + 20][i] == respostas_corretas[questao + 20]:
                                    cor_rect[i] = "darkgreen"
                                    som_acerto.play()
                                    acertos += 1
                                else:
                                    cor_rect[i] = "red"
                                    som_erro.play()
                                proxima_fase += 1
                    if proxima_fase == 1:
                        if b_proximo.retangulo.collidepoint(posicao_mouse):
                            questao_ligacao += 1
                            carrega_atomo = True
                            proxima_fase = 0
                            mostrar_dica = False
                            cor_rect = ["#1EBDBC", "#1EBDBC", "#1EBDBC"]
                    if b_ajuda_sim.retangulo.collidepoint(posicao_mouse):
                        mostrar_dica = True
        elif questao_ligacao % 2 != 0:
            if questao_2 == 0:
                atomo_carbono.eventos()
                atomo_hidrogenio.eventos()
                atomo_nitrogenio.eventos()
            elif questao_2 == 1:
                atomo_fosforo.eventos()
                atomo_hidrogenio.eventos()
                atomo_hidrogenio2.eventos()
                atomo_hidrogenio3.eventos()
            elif questao_2 == 2:
                atomo_hidrogenio.eventos()
                atomo_hidrogenio2.eventos()
                atomo_selenio.eventos()
            elif questao_2 == 3 or questao_2 == 4:
                questao_ligacao += 1
                questao += 1
            if eventos.type == pygame.MOUSEBUTTONDOWN:
                primeiro_atomo = None
                segundo_atomo = None
                terceiro_atomo = None
                quarto_atomo = None
                if b_concluir.retangulo.collidepoint(posicao_mouse):
                    for atom in lista_atomos_atomos[questao_2 + 12]:
                        if atom.retangulo.collidepoint(c_retangulo1.x, c_retangulo1.y):
                            primeiro_atomo = atom.elemento
                            print("Primeiro:" + primeiro_atomo)
                        elif atom.retangulo.collidepoint(c_retangulo2.x, c_retangulo2.y):
                            segundo_atomo = atom.elemento
                            print("Segundo:" + segundo_atomo)
                        elif atom.retangulo.collidepoint(c_retangulo3.x, c_retangulo3.y):
                            terceiro_atomo = atom.elemento
                            print("Terceiro:" + terceiro_atomo)
                        elif atom.retangulo.collidepoint(c_retangulo4.x, c_retangulo4.y):
                            quarto_atomo = atom.elemento
                            print("quarto:" + quarto_atomo)

                    resposta_dada = [primeiro_atomo, segundo_atomo, terceiro_atomo, quarto_atomo]
                    if resposta_dada == lista_resposta_ligacoes[questao_2 + 12]:
                        som_acerto.play()
                        acertos += 1
                    else:
                        som_erro.play()
                    questao += 1
                    questao_2 += 1
                    questao_ligacao += 1


numero_texto = 0


class C_teoria:
    def __init__(self):
        global numero_texto
        if numero_texto == len(textos_teoria):
            numero_texto = 0
        y = 200 * escala_y
        y2 = 70 * escala_y
        b_voltar_teoria.draw()
        fundo = img("imagens/8.png", 0, 0, largura, altura)
        b_passar_texto.draw()
        tela.blit(texto_proximo, (1325 * escala_x, 718 * escala_y))
        linhas_titulos = quebra_linhas(titulos_teoria[numero_texto], 1100*escala_x)
        for linha in linhas_titulos:
            texto = fonte3.render(linha, True, "black")
            tela.blit(texto, (160 * escala_x, y2 * escala_y))
            y2 += texto.get_height() + (30 * escala_y)
        linhas_texto = quebra_linhas(textos_teoria[numero_texto], 750*escala_x)
        for linha in linhas_texto:
            texto = fonte.render(linha, True, "black")
            tela.blit(texto, (160 * escala_x, y * escala_y))
            y += texto.get_height() + (30 * escala_y)
        if numero_texto != 8:
            img_teoria_original = pygame.image.load("imagens/t" + str(numero_texto+1) + ".jpg")
            img_teoria = pygame.transform.scale(img_teoria_original, (470 * escala_x, 310 * escala_y))
            tela.blit(img_teoria, (835*escala_x, 230*escala_y))


class C_opcao:
    def __init__(self):
        global mostrar_dica
        b_voltar.draw()
        self.fundo = img("imagens/9.png", 0, 0, largura, altura)
        if tela_anterior == 2 or tela_anterior == 5 or tela_anterior == 7 or tela_anterior == 8 or tela_anterior == 9:
            sair_da_fase.draw()
            tela.blit(texto_sair_fase, (70 * escala_x, 235 * escala_y))
            mostrar_dica = False


class C_fim:
    def __init__(self):
        b_menu.draw()
        b_proxima_fase.draw()
        self.fundo = img("imagens/12.png", 0, 0, largura, altura)
        frasco_original = pygame.image.load("imagens/" + str(acertos * 10) + ".png")
        if acertos != 1:
            frasco = pygame.transform.scale(frasco_original, (200 * escala_x, 232 * escala_y))
        else:
            frasco = pygame.transform.scale(frasco_original, (740 * escala_x, 345 * escala_y))
        texto = fonte2.render(str(((acertos * 10) // 8) * 10) + "%", True, "white")
        if acertos != 1:
            tela.blit(frasco, (670 * escala_x, 300 * escala_y))
        else:
            tela.blit(frasco, (440 * escala_x, 280 * escala_y))
        tela.blit(texto, (725 * escala_x, 440 * escala_y))


class C_creditos:
    def __init__(self):
        self.fundo = img("imagens/11.png", 0, 0, largura, altura)


b_jogar = Botao(610 * escala_x, 423 * escala_y, 283 * escala_x, 105 * escala_y, "black", 50)
b_teoria = Botao(637 * escala_x, 538 * escala_y, 238 * escala_x, 103 * escala_y, "black", 50)
b_opcao = Botao(48 * escala_x, 40 * escala_y, 95 * escala_x, 95 * escala_y, "black", 50)
b_opcao2 = Botao(141 * escala_x, 41 * escala_y, 71 * escala_x, 71 * escala_y, "black", 50)
b_opcaojogo1 = Botao(36 * escala_x, 36 * escala_y, 71 * escala_x, 71 * escala_y, "black", 50)
b_opcaojogo2 = Botao(36 * escala_x, 36 * escala_y, 71 * escala_x, 71 * escala_y, "black", 50)
b_opcaojogo3 = Botao(36 * escala_x, 36 * escala_y, 71 * escala_x, 71 * escala_y, "black", 50)
b_opcaojogo4 = Botao(36 * escala_x, 36 * escala_y, 71 * escala_x, 71 * escala_y, "black", 50)
b_opcaojogo5 = Botao(36 * escala_x, 36 * escala_y, 71 * escala_x, 71 * escala_y, "black", 50)
b_fase = Botao(320 * escala_x, 293 * escala_y, 168 * escala_x, 168 * escala_y, "black", 200)
b_fase2 = Botao(692 * escala_x, 293 * escala_y, 168 * escala_x, 168 * escala_y, "black", 200)
b_fase3 = Botao(1052 * escala_x, 293 * escala_y, 168 * escala_x, 168 * escala_y, "black", 200)
b_fase4 = Botao(478 * escala_x, 532 * escala_y, 168 * escala_x, 168 * escala_y, "black", 200)
b_fase5 = Botao(890 * escala_x, 532 * escala_y, 168 * escala_x, 168 * escala_y, "black", 200)
b_proximo = Botao(1300 * escala_x, 700 * escala_y, 160 * escala_x, 70 * escala_y, "#23B690", 50)
texto_proximo = fonte.render("Próximo", True, "black")
b_proxima_fase = Botao(658 * escala_x, 567.5 * escala_y, 222 * escala_x, 82 * escala_y, "black", 50)
b_menu = Botao(658 * escala_x, 670 * escala_y, 222 * escala_x, 82 * escala_y, "black", 50)
b_voltar = Botao(48 * escala_x, 24 * escala_y, 78 * escala_x, 77 * escala_y, "black", 0)
b_voltar_fase = Botao(59 * escala_x, 45 * escala_y, 58 * escala_x, 58 * escala_y, "black", 0)
b_voltar_teoria = Botao(25 * escala_x, 32 * escala_y, 78 * escala_x, 77 * escala_y, "black", 0)
rect_jogar = pygame.rect.Rect(446 * escala_x, -255 * escala_y, 635.3444791666666 * escala_x, 452.060625 * escala_y)
sair_da_fase = Botao(27 * escala_x, 200 * escala_y, 300 * escala_x, 110 * escala_y, "#5DF997", 40)
texto_sair_fase = fonte3.render("Sair da Fase", True, "black")
retangulo_cabeca = Botao(1290 * escala_x, 105 * escala_y, 175 * escala_x, 123 * escala_y, "black", 0)
b_ajuda_nao = Botao(1390 * escala_x, 270 * escala_y, 50 * escala_x, 50 * escala_y, "darkred", 0)
b_ajuda_sim = Botao(1319 * escala_x, 270 * escala_y, 130 * escala_x, 50 * escala_y, "#23B690", 15)
texto_quero_ajuda = fonte.render("Quero!", True, "black")
b_concluir = Botao(1300 * escala_x, 700 * escala_y, 160 * escala_x, 70 * escala_y, "#23B690", 50)
b_passar_texto = Botao(1300 * escala_x, 700 * escala_y, 160 * escala_x, 70 * escala_y, "#23B690", 50)

telas = []
retangulos = []
ative_events = []
tela_atual = 0
tela_anterior = None
mostrar_dica = False

tela1 = C_jogar()
tela2 = C_jogo1()
tela5 = C_jogo2()
tela7 = C_jogo3()
tela8 = C_jogo4()
tela9 = C_jogo5()


for i in range(3):
    retangulo = pygame.Rect(237 * escala_x, (270 + i * 200) * escala_y, 939 * escala_x, 160 * escala_y)
    retangulos.append(retangulo)

for i in range(0, 11):
    if i == 0:
        telaa = True
    else:
        telaa = False
    telas.append(telaa)

for i in range(len(telas)):
    if i == 0:
        ativee = True
    else:
        ativee = False
    ative_events.append(ativee)

loop = True
while loop:
    for i in range(len(telas)):
        if telas[i]:
            if i != tela_atual:
                tela_anterior = tela_atual
                tela_atual = i

    if telas[0]:
        C_inicio()
        ative_events[0] = True
    elif telas[1]:
        C_jogar().aparece()
        ative_events[1] = True
    elif telas[2]:
        C_jogo1().aparece()
    elif telas[3]:
        C_teoria()
        ative_events[3] = True
    elif telas[4]:
        C_opcao()
        ative_events[4] = True
    elif telas[5]:
        C_jogo2().aparece()
    elif telas[6]:
        C_fim()
        ative_events[6] = True
    elif telas[7]:
        C_jogo3().aparece()
    elif telas[8]:
        C_jogo4().aparece()
    elif telas[9]:
        C_jogo5().aparece()

    for i in range(len(ative_events)):
        if ative_events[i]:
            for o in range(len(ative_events)):
                if o != i:
                    ative_events[o] = False

    for eventos in pygame.event.get():
        if eventos.type == pygame.KEYDOWN:
            if eventos.key == pygame.K_ESCAPE:
                loop = False

        posicao_mouse = pygame.mouse.get_pos()
        if eventos.type == pygame.MOUSEBUTTONDOWN and ative_events[6]:
            if b_proxima_fase.retangulo.collidepoint(posicao_mouse):
                print("proxima")
                if tela_anterior == 2:
                    telas[tela_atual] = False
                    ative_events[6] = False
                    telas[5] = True
                    acertos = 0
                elif tela_anterior == 5:
                    telas[tela_atual] = False
                    ative_events[6] = False
                    telas[7] = True
                    acertos = 0
                elif tela_anterior == 7:
                    telas[tela_atual] = False
                    ative_events[6] = False
                    telas[8] = True
                    acertos = 0
                elif tela_anterior == 8:
                    telas[tela_atual] = False
                    ative_events[6] = False
                    telas[9] = True
                    acertos = 0
                elif tela_anterior == 9:
                    telas[tela_atual] = False
                    ative_events[6] = False
                    telas[2] = True
                    acertos = 0
        if eventos.type == pygame.MOUSEBUTTONDOWN:
            if b_passar_texto.retangulo.collidepoint(posicao_mouse) and ative_events[3]:
                numero_texto += 1

        if tela_anterior == 2 or tela_anterior == 5 or tela_anterior == 7 or tela_anterior == 8 or tela_anterior == 9 and \
                ative_events[4]:
            if eventos.type == pygame.MOUSEBUTTONDOWN:
                if sair_da_fase.retangulo.collidepoint(posicao_mouse):
                    telas[4] = False
                    ative_events[4] = False
                    telas[1] = True
                    ative_events[1] = True

                    questao = 0
                    questao_2 = 0
                    questao_ligacao = 0
                    cor_rect = ["#1EBDBC", "#1EBDBC", "#1EBDBC"]
                    proxima_fase = 0
        if telas[2]:
            tela2.evento()
        if telas[5]:
            tela5.evento()
        if telas[7]:
            tela7.evento()
        if telas[8]:
            tela8.evento()
        if telas[9]:
            tela9.evento()
        if telas[1]:
            tela1.eventos()


        b_jogar.funcao(0, 1)
        b_fase.funcao(1, 2)
        b_fase2.funcao(1, 5)
        b_fase3.funcao(1, 7)
        b_fase4.funcao(1, 8)
        b_fase5.funcao(1, 9)
        b_teoria.funcao(0, 3)
        b_opcao.funcao(0, 4)
        b_opcao2.funcao(1, 4)
        b_opcaojogo1.funcao(2, 4)
        b_opcaojogo2.funcao(5, 4)
        b_opcaojogo3.funcao(7, 4)
        b_opcaojogo4.funcao(8, 4)
        b_opcaojogo5.funcao(9, 4)
        b_menu.funcao(6, 1)
        b_voltar.funcao(4, tela_anterior)
        b_voltar_fase.funcao(1, 0)
        b_voltar_teoria.funcao(3, 0)

    pygame.display.update()

    # Fases de ligação                                              Nada                       Díficil      Chato
    # Coisas tela de teoria                                         Menos da Metade            Médio        Chato
    # Ajudas do robô                                                Praticamente Feito         Fácil        De boa
    # Quantidades de acertos em cada fase                           Feito                       Fácil        De boa
    # Resolver ERRO do botão sair da fase                           Feito                      Fácil        De boa
    # Tela Sobre                                                    Não Obrigatório            Fácil        De boa
    # Ajustes nas questões se necessário                            Não Obrigatório
